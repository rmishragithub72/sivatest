package com.aashdit.notification;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class NotificationController {
    @Autowired
    NotifyService notifyService;
    @PostMapping(path="/notify/{mobileNo}",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ServiceResult> doNotify(@RequestBody NotificationMessage message, @PathVariable String mobileNo){
        int res = notifyService.sendSMS(mobileNo,message.getMessage());

        ServiceResult result = null;
        if(res ==0)
            result = new ServiceResult(Result.SUCCESS,"Send Success for:"+ mobileNo);
        else
            result = new ServiceResult(Result.FAILURE,"Failed to send for:"+ mobileNo);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
