package com.aashdit.notification;

public enum Result {
    SUCCESS,
    FAILURE;
}
