package com.aashdit.notification;

import java.io.Serializable;

public class NotificationMessage implements Serializable {
    String message;

    public NotificationMessage() {
    }

    public NotificationMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
