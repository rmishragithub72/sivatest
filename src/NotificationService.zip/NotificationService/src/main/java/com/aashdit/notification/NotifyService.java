package com.aashdit.notification;

import org.springframework.stereotype.Service;

@Service
public class NotifyService {
    public int sendSMS(String mobileNo, String message){
        System.out.println("Going to send SMS for " + mobileNo);
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        //some dynamic failure cases when mobile number ends with digit 3
        if(mobileNo.endsWith("3")){
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("Failed to send SMS for " + mobileNo);
            return 1;
        }
        System.out.println("SMS sent for " + mobileNo);
        return 0;
    }
}
