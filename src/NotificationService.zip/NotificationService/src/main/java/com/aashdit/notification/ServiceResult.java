package com.aashdit.notification;

import java.io.Serializable;

public class ServiceResult implements Serializable {
    Result result;
    String description;

    public ServiceResult() {
    }

    public ServiceResult(Result result, String description) {
        this.result = result;
        this.description = description;
    }

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
