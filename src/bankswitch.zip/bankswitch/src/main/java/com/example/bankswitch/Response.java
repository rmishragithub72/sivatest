package com.example.bankswitch;

import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Response implements Serializable {
    int code;
    String description;
    Request request;
}
