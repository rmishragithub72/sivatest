package com.jasperdemo.service;

import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class SummaryRepo {
    public List<DistrictWiseCount> findDistrictWiseCount() {
        return Arrays.asList(
          new DistrictWiseCount("Khorda", 31),
                new DistrictWiseCount("Sundargarh",75),
                new DistrictWiseCount("Sambalpur", 25)
        );
    }
}
