package com.jasperdemo.controller;

import com.jasperdemo.service.DistrictWiseCount;
import com.jasperdemo.service.SummaryRepo;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import net.sf.jasperreports.engine.*;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ReportController {
    @Autowired
    SummaryRepo summaryRepo;

    @GetMapping("/")
    public String getHome(){
        return "welcome";
    }

    @GetMapping("/districtCount")
    public ResponseEntity<byte[]> getDistrictWiseCount() throws JRException, FileNotFoundException {
        List<DistrictWiseCount> districtWiseCounts = summaryRepo.findDistrictWiseCount();

        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(districtWiseCounts);
        JasperReport jasperReport  = JasperCompileManager.compileReport(
                    new FileInputStream(ResourceUtils.getFile("classpath:reports/DistrictWiseCount.jrxml")));

        Map<String,Object> map = new HashMap<>();
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, dataSource);
        byte[] data = JasperExportManager.exportReportToPdf(jasperPrint);


        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION,"inline;filename=report.pdf");
        return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(data);

    }

    @GetMapping("/districtCountHtml")
    public ResponseEntity<byte[]> getDistrictWiseCounthtml() throws JRException, IOException, InterruptedException {
        List<DistrictWiseCount> districtWiseCounts = summaryRepo.findDistrictWiseCount();

        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(districtWiseCounts);
        JasperReport jasperReport  = JasperCompileManager.compileReport(
                new FileInputStream(ResourceUtils.getFile("classpath:reports/DistrictWiseCount.jrxml")));

        Map<String,Object> map = new HashMap<>();
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, map, dataSource);
        JasperExportManager.exportReportToHtmlFile(jasperPrint,"src/main/resources/static/images/sivareport.html");
        System.out.println("html file generated");

        Thread.sleep(300);
        System.out.println("html file generated");
        File serverFile = new File("src/main/resources/static/images/sivareport.html_files/img_0_0_1.png");
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION,"inline;filename=report.pdf");
        return ResponseEntity.ok().headers(headers).contentType(MediaType.IMAGE_PNG)
                .body(Files.readAllBytes(serverFile.toPath()));

    }


}
