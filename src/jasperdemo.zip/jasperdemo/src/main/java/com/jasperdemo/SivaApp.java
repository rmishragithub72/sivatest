package com.jasperdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SivaApp {
    public static void main(String[] args) {
        SpringApplication.run(SivaApp.class,args);
    }
}
