package com.example.banksimulator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanksimulatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
