package com.example.dualDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DualDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
