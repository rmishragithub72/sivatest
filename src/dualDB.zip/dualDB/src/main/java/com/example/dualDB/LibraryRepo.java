package com.example.dualDB;

import org.springframework.data.repository.CrudRepository;


public interface LibraryRepo extends CrudRepository<LibraryInfo, Integer> {
}
