package com.example.dualDB;

import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.stereotype.Service;

@Service
public class EntityManagerUtil {
    @Autowired
    @Qualifier("firstEntityManager")
    private EntityManager firstDbManger;

    @Autowired
    @Qualifier("secondEntityManager")
    private EntityManager secondDbManager;

    private EntityManager getEntityManager(String str){
        if(str.contains("Govt")){
            System.out.println("first db as received college as:" + str);
            return firstDbManger;
        } else {
            System.out.println("second db as received college as:" + str);

            return secondDbManager;
        }
    }

    public JpaRepositoryFactory getJPAFactory(String s){
        return new JpaRepositoryFactory(getEntityManager(s));
    }
}
