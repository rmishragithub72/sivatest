package com.example.dualDB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Scope("prototype")
public class LibraryController {
    @Autowired
    EntityManagerUtil entityManagerUtil;

    @GetMapping("/library/{college}/all")
    public List<LibraryInfo> getLibInfo(@PathVariable("college") String college) {

        LibraryRepo repository = entityManagerUtil.getJPAFactory(college).getRepository(LibraryRepo.class);
        return (List<LibraryInfo>) repository.findAll();
    }
}
