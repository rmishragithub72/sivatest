package com.example.dualDB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class MyController {
    @Autowired
    StudentRepo studentRepo;

    @GetMapping("/")
    public String getRoot() {
        return "Welcome to Global Site!!!";
    }
    @GetMapping("/all")
    public List<Student> getAll(){
        return (List<Student>) studentRepo.findAll();
    }


}
