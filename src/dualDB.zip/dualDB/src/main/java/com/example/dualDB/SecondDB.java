package com.example.dualDB;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@ComponentScan("com.example.dualDB")

public class SecondDB {
    @Value("${seconddb.url}")
    String url;

    @Value("${seconddb.username}")
    String username;

    @Value("${seconddb.password}")
    String password;

    @Value("${spring.datasource.driver-class-name}")
    String driverName;

    @Bean("secondDatasource")
    public DataSource secondDataSource(){
        DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
        driverManagerDataSource.setDriverClassName(driverName);
        driverManagerDataSource.setUrl(url);
        driverManagerDataSource.setUsername(username);
        driverManagerDataSource.setPassword(password);
        return driverManagerDataSource;
    }

    @Bean("secondEntityManager")
    public LocalContainerEntityManagerFactoryBean secondEntityManager(){
        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean =
                new LocalContainerEntityManagerFactoryBean();
        entityManagerFactoryBean.setPackagesToScan(new String[]{"com.example.dualDB"});
        entityManagerFactoryBean.setDataSource(secondDataSource());
        entityManagerFactoryBean.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        entityManagerFactoryBean.setJpaProperties(hibernateProperties());
        return entityManagerFactoryBean;
    }

    private Properties hibernateProperties() {
        Properties properties = new Properties();
//        properties.put("hibernate.hbm2ddl.auto", false);
        properties.put("hibernate.show_sql",true);
        return properties;
    }

    @Bean("secondTransactionManager")
    public PlatformTransactionManager secondTransactionManager(){
        JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
        jpaTransactionManager.setEntityManagerFactory(secondEntityManager().getObject());
        return jpaTransactionManager;
    }

    @Bean("secondSessionFactory")
    public LocalSessionFactoryBean secondSessionFactory(){
        LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();
        localSessionFactoryBean.setPackagesToScan(new String[]{"com.example.dualDB"});
        localSessionFactoryBean.setDataSource(secondDataSource());
        localSessionFactoryBean.setHibernateProperties(hibernateProperties());
        return localSessionFactoryBean;
    }

}
